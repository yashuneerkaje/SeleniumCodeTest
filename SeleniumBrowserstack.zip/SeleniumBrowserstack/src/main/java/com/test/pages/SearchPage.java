package com.test.pages;

public class SearchPage {
}
